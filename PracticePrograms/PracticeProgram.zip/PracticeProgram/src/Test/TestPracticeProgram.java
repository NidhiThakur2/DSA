package Test;

import PracticePrograms.DecimalConversion;
import PracticePrograms.PowerOf10;
import PracticePrograms.PowerOfExpo;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;


public class TestPracticeProgram {

    @Test
    public void testPowerOfExpo(){
        PowerOfExpo powerOfExpo=new PowerOfExpo();
        int result=powerOfExpo.findPowerOfExpo(-2,4,1);
        assertEquals(16,result);
    }
    @Test
    public void testPowerOfExpoNegative(){
        PowerOfExpo powerOfExpo=new PowerOfExpo();
        int result=powerOfExpo.findPowerOfExpo(2,-4,1);
        assertEquals(-1,result);
    }
    @Test
    public void testPowerOf10(){
        PowerOf10 powerOf10=new PowerOf10();
        Boolean result=powerOf10.isPowerOf10(40);
        assertEquals(true,result);
    }
    @Test
    public void testfractionToDecimal(){
        DecimalConversion decimalConversion=new DecimalConversion();
        String result=decimalConversion.fractionToDecimal(10,3);
        assertEquals("3.(3)",result);
    }
    @Test
    public void testfractionToDecimalNegative(){
        DecimalConversion decimalConversion=new DecimalConversion();
        String result=decimalConversion.fractionToDecimal(10,0);
        assertEquals("Inappropriate Operation",result);
    }

}
