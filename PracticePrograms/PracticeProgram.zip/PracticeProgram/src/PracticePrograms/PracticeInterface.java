package PracticePrograms;
public class PracticeInterface {
    public static void main(String[] args) {

    }
}
