package PracticePrograms;

public class Employee {

}
