package PracticePrograms;

public interface A {
        default void greet(){
            System.out.println("Hi From Interface A");
        }
}
